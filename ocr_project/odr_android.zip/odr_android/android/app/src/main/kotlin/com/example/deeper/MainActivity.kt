package com.example.deeper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
