import 'package:deeper/widgets/home_container.dart';
import 'package:deeper/widgets/select_image_item.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:tflite/tflite.dart';
import 'results_screen.dart';
import 'package:image_cropper/image_cropper.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late bool _isLoading;
  late PickedFile _image;
  late List _output;

  final kHeaderTextStyle = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
  );

  @override
  void initState() {
    super.initState();
    _isLoading = true;
    loadMLModel().then((value) {
      setState(() {
        _isLoading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.black87,
        title: Text('Optical Digit Recognizer'),
        leading: GestureDetector(
          onTap: () {},
          child: Icon(
            Icons.menu,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: GestureDetector(child: Icon(Icons.more_vert)),
          ),
        ],
      ),
      body: _isLoading ? HomeContainer(key: Key('null'),) : HomeContainer(key: Key('nuller')),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton(
        tooltip: 'Add Image',
        elevation: 0,
        backgroundColor: Colors.black87,
        onPressed: () {
          chooseImage();
        },
        child: Icon(Icons.image),
      ),
    );
  }

  void chooseImage() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.only(right: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      'Select Image',
                      textDirection: TextDirection.rtl,
                      style: kHeaderTextStyle.copyWith(color: Colors.grey[800]),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                height: 0.5,
                width: double.infinity,
                color: Colors.grey,
              ),
              SizedBox(
                height: 10,
              ),
              InkWell(
                onTap: () {
                  chooseFromCamera();
                },
                borderRadius: BorderRadius.circular(10),
                child: SelectImageItem(
                  text: 'From Camera',
                  iconData: Icons.camera_alt,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              InkWell(
                borderRadius: BorderRadius.circular(10),
                onTap: () {
                  chooseFromGallery();
                },
                child: SelectImageItem(
                  text: 'From Gallery',
                  iconData: Icons.insert_photo,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  chooseFromCamera() async {
    // ignore: deprecated_member_use
    var image = await ImagePicker().getImage(source: ImageSource.camera);
    if (image == null) return null;
      _isLoading = true;
      _image = image;
      await _cropImage();
      File file = File.fromUri(Uri.parse(_image.path));
      runModelOnImage(file);
      setState(() {

      });
      Navigator.pop(context);
  }

  chooseFromGallery() async {
    // ignore: deprecated_member_use
    var image = await ImagePicker().getImage(source: ImageSource.gallery);
    if (image == null) return null;
    _isLoading = true;
    _image = image;
    await _cropImage();
    File file = File.fromUri(Uri.parse(_image.path));
    runModelOnImage(file);
    setState(() {

    });
    Navigator.pop(context);
  }

  Future<void> _cropImage() async {
    try {
      File? cropped = await ImageCropper.cropImage(
        cropStyle: CropStyle.rectangle,
        sourcePath: _image.path,
        aspectRatio: CropAspectRatio(ratioX: 20.0, ratioY: 5.0),
      );

      setState(() {
        _image = PickedFile(cropped!.path) ?? _image;
      });
    } catch (e) {
      print(e);
    }
  }

  runModelOnImage(File image) async {
    var output = await Tflite.runModelOnImage(
      path: image.path,
      numResults: 2,
      imageMean: 127.5,
      imageStd: 127.5,
      // threshold: 0.5,
    );
    print('-----------------------------------------------------------------------------');
    print(output);
    setState(() {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ResultsScreen(image: File.fromUri(Uri.parse(_image.path)), output: _output, key: Key('null'),),
        ),
      );
      _output = output!;
    });
  }

  loadMLModel() async {
    await Tflite.loadModel(
      model: 'assets/converted_model.tflite',
      // labels: 'assets/labels.txt',
    );
  }
}
